
package latihankuiz;


public class LatihanKuiz {


    public static void main(String[] args) {
        LPage loginPage = new LPage();
    }
    
}
