
package latihankuiz;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class HPage extends JFrame implements ActionListener{
    JLabel homeTitle = new JLabel();
    JLabel desc = new JLabel();
    JButton mjlhAnak = new JButton("Majalah Anak");
    JButton mjlhRemaja = new JButton("Majalah Remaja");
    JButton mjlhDewasa = new JButton("Majalah Dewasa"); 
    String kategori;
    double harga; 
    
    public HPage(String user){
        setTitle("Halaman Utama");
        setLayout(null);
        setVisible(true);
        setSize(480, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        add(homeTitle);
        add(desc);
        add(mjlhAnak);
        add(mjlhRemaja);
        add(mjlhDewasa);
        
        homeTitle.setBounds(100, 120, 300, 20);
        desc.setBounds(100, 145, 400, 20);
        
        mjlhAnak.setBounds(100, 185, 250, 35);
        mjlhRemaja.setBounds(100, 230, 250, 35);
        mjlhDewasa.setBounds(100, 275, 250, 35);
        
        mjlhAnak.addActionListener(this);
        mjlhRemaja.addActionListener(this);
        mjlhDewasa.addActionListener(this);

        homeTitle.setText("Selamat Datang, " + user + "!");
        desc.setText("Silahkan pilih menu dibawah untuk memesan majalah");
        desc.setFont(new Font("Arial", Font.ITALIC, 11));
    }
    
    
    @Override
    public void actionPerformed(ActionEvent g){
        try{
            if(g.getSource() == mjlhAnak){
                kategori = "Majalah Anak";
                harga = 10.800;
                new MPage(this, kategori, harga); // membawa frame halaman ini ke halaman selanjutnya
                this.setVisible(false); // halaman ini disembunyikan
            } else if(g.getSource() == mjlhRemaja){
                kategori = "Majalah Remaja";
                harga = 15.200;
                new MPage(this, kategori, harga);
                this.setVisible(false);
            } else if(g.getSource() == mjlhDewasa){
                kategori = "Majalah Dewasa";
                harga = 25.400;
                new MPage(this, kategori, harga);
                this.setVisible(false);
            }
        } catch(Exception error){
            JOptionPane.showMessageDialog(this, error.getMessage());
        }
    }

}
