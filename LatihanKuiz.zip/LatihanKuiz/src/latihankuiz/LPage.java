
package latihankuiz;
import javax.swing.*;
import java.awt.event.*;

public class LPage extends JFrame implements ActionListener{
    JButton loginButton = new JButton("Login");
    JButton resetButton = new JButton("Reset");
    JLabel userLabel = new JLabel("Username");
    JLabel passLabel = new JLabel("Password");
    JTextField userTF = new JTextField();    
    JPasswordField passTF = new JPasswordField();
    JLabel title = new JLabel("Silahkan Login Dulu");

    
    public LPage(){
        setTitle("Halaman Login");
        setLayout(null);
        setVisible(true);
        setSize(480, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        add(loginButton);
        add(resetButton);
        add(userLabel);
        add(passLabel);
        add(userTF);
        add(passTF);
        add(title);
        
        title.setBounds(140, 80, 300, 20);
        
        userLabel.setBounds(100, 120, 100, 20);
        userTF.setBounds(100, 150, 250, 35);
        
        passLabel.setBounds(100, 205, 100, 20);
        passTF.setBounds(100, 235, 250, 35);
        
        loginButton.setBounds(100, 290, 100, 35);
        loginButton.addActionListener(this);
        
        resetButton.setBounds(250, 290, 100, 35);
        resetButton.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent button){
        try {
            if(button.getSource() == loginButton){
                String username = userTF.getText();
                String password = passTF.getText();
                
                if(username.equals("123230160") && password.equals("pass12345")){
                    new HPage(username);
                    this.dispose();
                }else{
                    JOptionPane.showMessageDialog(this, "Username atau Password Anda Salah");
                }
            } else if(button.getSource() == resetButton){
                userTF.setText("");                
                passTF.setText("");
            }
        } catch(Exception error) {
            JOptionPane.showMessageDialog(this, error.getMessage());
        }
    }
}
