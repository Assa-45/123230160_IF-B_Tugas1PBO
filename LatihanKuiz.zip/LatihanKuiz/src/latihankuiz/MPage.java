
package latihankuiz;
import java.awt.event.*;
import java.awt.*; // jgn lupa import dulu gusy
import javax.swing.*;

public class MPage extends JFrame implements ActionListener{
    JLabel kLabel = new JLabel("Kategori");
    JLabel hLabel = new JLabel("Harga");
    JLabel jLabel = new JLabel("Jumlah");
    JTextField amount = new JTextField();
    JButton back = new JButton("Kembali");
    JButton buy = new JButton("Beli");

    JLabel totalLabel = new JLabel("Total Pembelian : ");
    JLabel hargaSatuanLabel = new JLabel("Harga Satuan");
    JLabel totalHargaLabel = new JLabel("Total Harga");
    JLabel jmlh = new JLabel("Jumlah");
    
    JLabel hargaSatuan;
    JLabel totalHarga;
    JLabel jmlhPcs;
    
    double harga; // deklarasi harga dihalaman MPage
    
    JFrame pFrame; // deklarasi JFrame awal yg bernilai null
    
    Font font = new Font("Arial", Font.PLAIN, 13); // buat font baru buat ganti font
    
    public MPage(JFrame prevFrame, String kategori, double harga){
        // prevFrame membawa frame dari halaman sebelumnya kesini
        // pFrame "ini / hasil deklarasi di halaman ini" diisi dgn JFrame dari parameter di konstruktor
        this.pFrame = prevFrame; // frame halaman sebelumnya dicopy kesini
        this.harga = harga; // bahwa harga yg dihalaman ini tu sama kyk harga yg dibawa di parameternya
        
        setTitle("Halaman Pembelian");
        setLayout(null);
        setVisible(true);
        setSize(480, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JLabel category = new JLabel(kategori);
        String strharga = String.format("%.3f", harga); // ubah double jadi string
        JLabel price = new JLabel("Rp" + strharga + " /pcs");
        
        hargaSatuan = new JLabel("Rp" + strharga);
        
        add(kLabel); add(hLabel); add(jLabel);     
        add(category); add(price); add(amount);
        add(back); add(buy);
        add(jmlh); add(totalLabel); add(hargaSatuanLabel); add(totalHargaLabel);
        add(hargaSatuan); 

        kLabel.setBounds(80, 50, 100, 20);
        hLabel.setBounds(80, 80, 100, 20);
        jLabel.setBounds(80, 110, 100, 20);
        category.setBounds(200 , 50, 100, 20);
        price.setBounds(200, 80, 100, 20);
        amount.setBounds(200, 110, 100, 20);
        
        back.setBounds(80, 150, 100, 30);
        buy.setBounds(200, 150, 100, 30);
        
        back.addActionListener(this);
        buy.addActionListener(this);
        
        // langkah untuk mengganti font yg astaghfirullah panjang bet
        
        // masukin ke array
        JLabel[] labels = {kLabel, hLabel, jLabel, totalLabel, hargaSatuanLabel, totalHargaLabel, jmlh, category, price};
       
        // sebarin fontnya make for loop
        for(JLabel label : labels){ // untuk semua label yg ada di array labels ...
            label.setFont(font);
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent h){
        try{
            String strjmlh = amount.getText();
            if(h.getSource() == buy){
                if(!strjmlh.isEmpty()){
                    double pcs = harga * Double.parseDouble(strjmlh);
                    String total = String.format("%.3f", pcs);

                    totalHarga = new JLabel("Rp" + total);
                    jmlhPcs = new JLabel(strjmlh + " pcs");
                    
                    // add nya baru disini biar bisa di update dulu baru dimunculin
                    add(totalHarga); 
                    add(jmlhPcs);
                    
                    // kasi jg disini
                    JLabel[] labels2 = {totalHarga, jmlhPcs, hargaSatuan};
                    for(JLabel label2 : labels2){ // untuk semua label yg ada di array labels ...
                        label2.setFont(font);
                    }
                    
                    totalLabel.setBounds(80, 220, 200, 20);
                    hargaSatuanLabel.setBounds(80, 250, 100, 20);
                    jmlh.setBounds(80, 280, 100, 20);
                    totalHargaLabel.setBounds(80, 310, 100, 20);

                    hargaSatuan.setBounds(200, 250, 100, 20);
                    jmlhPcs.setBounds(200, 280, 100, 20);
                    totalHarga.setBounds(200, 310, 200, 20);
                } else {
                    JOptionPane.showMessageDialog(this, "Jumlah tidak boleh kosong");
                }
                
            }else if(h.getSource() == back){
                pFrame.setVisible(true); // frame halaman sebelumnya dimunculin lagi
                this.dispose(); // next halaman yg ini dihapus
            }
        }catch(Exception error){
            JOptionPane.showMessageDialog(this, error.getMessage());
        }
    }
}
